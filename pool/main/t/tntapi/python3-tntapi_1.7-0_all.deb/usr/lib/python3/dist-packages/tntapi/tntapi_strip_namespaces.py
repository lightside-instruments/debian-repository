#!/usr/bin/python
import lxml
import litenc_lxml

def strip_namespaces(tree):
	return litenc_lxml.strip_namespaces(tree)
