from distutils.core import setup

setup(name='yangcli',
	  version='0.0.1',
	  description="Python yangcli",
	  author="Vladimir Vassilev",
	  author_email="vladimir@lightside-instruments.com",
	  url="http://yuma123.org/wiki",
	  packages=["yangcli"],
	  license="Apache License 2.0",
	  platforms=["Posix; OS X; Windows"],
	  #classifiers=[]
	  #scripts=['scripts/myscript']
	  )
