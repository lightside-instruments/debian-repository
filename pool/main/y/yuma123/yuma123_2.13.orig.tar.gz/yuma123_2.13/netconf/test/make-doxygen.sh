# Build Doxygen Documentation for the Yuma test Harness
doxygen Doxyfile
