#!/bin/sh
python tntapi-yangcli.py --config=./topology.xml
